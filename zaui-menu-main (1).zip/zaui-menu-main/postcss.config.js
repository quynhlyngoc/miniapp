module.exports = {
  plugins: {
    'postcss-preset-env': {},
    tailwindcss: {},
    autoprefixer: {},
  },
};
