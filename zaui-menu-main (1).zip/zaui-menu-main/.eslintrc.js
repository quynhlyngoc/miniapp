module.exports = {
  root: true,
  extends: ['@xuannghia/eslint-config/react'],
  ignorePatterns: ['*.js', '*.cjs'],
}
