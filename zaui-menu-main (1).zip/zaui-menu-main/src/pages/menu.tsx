const MerchantMenuPage = () => {
  const menu = [
    { name: 'Vịt Quay Bắc Kinh', price: '780,000₫' },
    { name: 'Hủ Gạo', price: '60,000₫' },
    { name: 'Miến Xào Cua', price: '120,000₫' },
  ];

  return (
    <div className="p-4">
      <h2 className="text-lg font-bold mb-4">Menu Nhà Hàng Dim Tu Tac</h2>
      <ul className="space-y-4">
        {menu.map((item, idx) => (
          <li key={idx} className="border-b pb-2">
            <span>{item.name}</span>
            <br />
            <span className="text-gray-500">{item.price}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default MerchantMenuPage;
