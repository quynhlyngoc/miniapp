import { SVGProps } from 'react'

export type SvgIconProps = SVGProps<SVGSVGElement> & { size?: number }
